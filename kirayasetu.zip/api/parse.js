// Vercel serverless function: landlord ki boli hui baat → listing form ka JSON (Gemini)
// Key Vercel ke Environment Variable GEMINI_API_KEY mein rehti hai — browser ko kabhi nahi dikhti.

const MODELS = ['gemini-2.5-flash', 'gemini-flash-latest', 'gemini-2.0-flash'];

const ENUMS = {
  room_type: ['room', '1rk', '1bhk', '2bhk', 'pg', 'shared'],
  furnished: ['unfurnished', 'semi', 'full'],
  electricity: ['included', 'separate', 'meter'],
  tenant_pref: ['any', 'family', 'bachelor', 'girls', 'boys'],
  food_pref: ['any', 'veg'],
};
const AMENITIES = ['Attached bathroom', 'Kitchen', 'Parking', 'WiFi', 'Cooler/AC', 'Almari', 'Geyser', 'Chhat', 'Pani 24 ghante', 'Inverter'];

function buildPrompt(text) {
  return `You read a spoken description of a rental room in India, said by the landlord in ANY Indian language or dialect (Hindi, Haryanvi, Punjabi, Bengali, Marathi, Gujarati, Tamil, Telugu, Kannada, Malayalam, Urdu, English or a mix). It came from speech-to-text, so expect spelling mistakes.

Return ONLY a JSON object with these keys (use null when the landlord did not say it — never guess):
- "title": short heading in simple Hinglish (Roman script), max 40 chars, like "1 kamra, Model Town" or "1 BHK, Sector 12"
- "rent": monthly rent as an integer in rupees. Convert spoken numbers: "saadhe chaar hazaar"/"साढ़े चार हज़ार" = 4500, "dhai hazaar" = 2500, "paune paanch hazaar" = 4750, "5k" = 5000, "das hazaar" = 10000
- "deposit": security deposit integer or null
- "room_type": one of ${JSON.stringify(ENUMS.room_type)} ("kamra"/"room" = "room", "1 RK" = "1rk")
- "furnished": one of ${JSON.stringify(ENUMS.furnished)}
- "electricity": one of ${JSON.stringify(ENUMS.electricity)} ("bijli alag" = "separate", "bijli shamil/included" = "included", "meter"/"sub meter" = "meter")
- "water_included": true/false/null
- "tenant_pref": one of ${JSON.stringify(ENUMS.tenant_pref)}
- "food_pref": one of ${JSON.stringify(ENUMS.food_pref)} ("sirf veg", "non-veg nahi" = "veg")
- "amenities": array using ONLY these exact strings: ${JSON.stringify(AMENITIES)}
- "locality": area/mohalla/sector name or null
- "city": city name in English or null
- "description": 1-2 short, clean sentences summarising anything else useful, in the same language the landlord spoke (fix speech-to-text errors). null if nothing extra.

Landlord said:
"""${text}"""`;
}

function clean(d) {
  const out = {};
  const str = (v, n) => (typeof v === 'string' && v.trim() ? v.trim().slice(0, n) : null);
  const int = v => { const n = parseInt(String(v ?? '').replace(/[^\d]/g, ''), 10); return Number.isFinite(n) && n > 0 && n < 10000000 ? n : null; };
  out.title = str(d.title, 60);
  out.rent = int(d.rent);
  out.deposit = int(d.deposit);
  for (const k of Object.keys(ENUMS)) out[k] = ENUMS[k].includes(d[k]) ? d[k] : null;
  out.water_included = typeof d.water_included === 'boolean' ? d.water_included : null;
  out.amenities = Array.isArray(d.amenities) ? d.amenities.filter(a => AMENITIES.includes(a)) : [];
  out.locality = str(d.locality, 80);
  out.city = str(d.city, 60);
  out.description = str(d.description, 500);
  return out;
}

module.exports = async (req, res) => {
  if (req.method !== 'POST') return res.status(405).json({ error: 'POST only' });
  const key = process.env.GEMINI_API_KEY;
  if (!key) return res.status(500).json({ error: 'GEMINI_API_KEY Vercel mein set nahi hai' });

  let body = req.body;
  if (typeof body === 'string') { try { body = JSON.parse(body); } catch { body = {}; } }
  const text = String(body?.text || '').trim().slice(0, 2000);
  if (!text) return res.status(400).json({ error: 'text khaali hai' });

  let last = '';
  for (const model of MODELS) {
    try {
      const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-goog-api-key': key },
        body: JSON.stringify({
          contents: [{ role: 'user', parts: [{ text: buildPrompt(text) }] }],
          generationConfig: { temperature: 0.1, responseMimeType: 'application/json' },
        }),
      });
      if (!r.ok) { last = `${model}: ${r.status} ${(await r.text()).slice(0, 200)}`; continue; }
      const j = await r.json();
      const raw = (j?.candidates?.[0]?.content?.parts || []).map(p => p.text || '').join('');
      const json = JSON.parse(raw.replace(/^\s*```(?:json)?/i, '').replace(/```\s*$/, '').trim());
      return res.status(200).json(clean(json));
    } catch (e) {
      last = `${model}: ${String(e).slice(0, 200)}`;
    }
  }
  return res.status(502).json({ error: 'AI abhi jawab nahi de raha', detail: last });
};

module.exports.clean = clean;
